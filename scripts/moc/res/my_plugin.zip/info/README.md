# Timetable

**View your custom timetable of the week**

![Screenshot of a timetable](img/screenshot.jpg)

## Features

- Easy customizable
- ...

## Setup

- Install this plugin
- ...

## Update notes

- ...

...